 #!/bin/bash

# If not running in a terminal, try to find one and re-run
if [ ! -t 0 ]; then
  if command -v x-terminal-emulator >/dev/null 2>&1; then
    x-terminal-emulator -e "$0"
  elif command -v gnome-terminal >/dev/null 2>&1; then
    gnome-terminal -- "$0"
  elif command -v konsole >/dev/null 2>&1; then
    konsole -e "$0"
  else
    # Fallback: Tell the user via a GUI popup if they have zenity or kdialog
    notify-send "Installer" "Please run this script inside a terminal."
  fi
  exit
fi

DIR="$(cd "$(dirname "$0")" && pwd)"


echo "Creating an install directory in your home folder called \".phiphifier\""
echo " "

mkdir -p "$HOME/.phiphifier"

echo "\nMoving TilePadder.class to the install directory"
echo " "

mv "$DIR/TilePadder.class" "$HOME/.phiphifier"

echo "\nMoving the \"tilepadder\" script to /usr/local/bin.. Need root permissions to finish installation"
echo " "

sudo mv "$DIR/tilepadder" /usr/local/bin/tilepadder
sudo chmod +x /usr/local/bin/tilepadder
